Thư mục docs: chứa 2 tập tin
1. I-12 Bao cao SmartShop: Báo cáo toàn văn sản phẩm
2. Phu luc - Huong dan phat trien he thong SmartShop: Hướng dẫn biên dịch và phát triển dự án

Thư mục src: chứa 2 project được phát triển bằng IDE Eclipse. Hướng dẫn biên dịch dự án được trình bày chi tiết trong file docs/Phu luc - Huong dan phat trien he thong SmartShop.pdf