package com.appspot.smartshop.utils;

public interface DataLoader {
	void loadData();
	void updateUI();
}
