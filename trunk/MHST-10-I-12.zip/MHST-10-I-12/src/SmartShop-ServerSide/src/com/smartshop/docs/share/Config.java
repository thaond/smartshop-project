package com.smartshop.docs.share;

public class Config {
	public static String HOST_NAME = "http://127.0.0.1:8888"; 
}
