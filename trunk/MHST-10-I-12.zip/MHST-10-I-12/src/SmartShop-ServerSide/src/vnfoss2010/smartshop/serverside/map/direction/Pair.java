package vnfoss2010.smartshop.serverside.map.direction;

public class Pair {
	String value;
	String text;
}
