package vnfoss2010.smartshop.serverside.map.direction;

import java.util.List;

public class Direction {
	String status;
	List<Route> routes;
}
