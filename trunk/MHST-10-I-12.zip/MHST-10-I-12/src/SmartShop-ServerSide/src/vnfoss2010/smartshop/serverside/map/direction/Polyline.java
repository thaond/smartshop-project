package vnfoss2010.smartshop.serverside.map.direction;

public class Polyline {
	String points;
	String levels;
}
