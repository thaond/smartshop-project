package vnfoss2010.smartshop.serverside.map.direction;

public class Step {
	String html_instructions;
	String travel_mode;
	Pair duration;
	Pair distance;
	GeoPoint start_location;
	GeoPoint end_location;
	Polyline polyline;
}
