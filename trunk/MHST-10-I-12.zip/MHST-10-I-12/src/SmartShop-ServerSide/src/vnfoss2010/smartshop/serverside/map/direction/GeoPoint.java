package vnfoss2010.smartshop.serverside.map.direction;

public class GeoPoint {
	public double lat;
	public double lng;

	public GeoPoint(double lat, double lng) {
		this.lat = lat;
		this.lng = lng;
	}
}
